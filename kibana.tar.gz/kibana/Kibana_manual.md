# Kibana使用手册
________________________
## 创建索引模式(Index Pattern)
**Index Pattern可以理解为索引视图，是日志查看搜索的起点**

选择Management中的Index Patterns
![Kibana_1](images/Kibana_1.jpg)

* Index name可以填入确定的ES索引名称或可以进行通用匹配如下图：nginx-access-log-*
* 若能成功匹配到索引，则可以点击“Create”创建
* **Time-field name很重要，这是选择日志中符合“date”类型的字段作为log event的时间，若要符合ES DATE类型，则该字段应该为“2017-05-26T13:18:06-07:00”的格式，在nginx log_format中log time字段应该取用"$time_iso8601"参数而不是$time_local；若没有选择Time-field name，则无法根据时间段来搜索日志**

![Kibana_2](images/Kibana_2.jpg)

创建成功
![Kibana_3](images/Kibana_3.jpg)
## 搜索日志
### 根据时间段搜索

点击右上角可选择时间段来查看日志
![Kibana_4](images/Kibana_4.jpg)

也可选择确切的时间段
![Kibana_5](images/Kibana_5.jpg)

### 根据条件搜索
Kibana的条件搜索格式遵循Lucene语法，详情请见:[Lucene Query Syntax](https://lucene.apache.org/core/2_9_4/queryparsersyntax.html#+)

举例：

* 查看返回状态码response字段为200的日志

     `response:200`

![Kibana_6](images/Kibana_6.jpg)


* 查看bytes为100到200直接并且remote_host不是127.0.0.1的事件

	`bytes:[100 TO 200] AND NOT remote_host:127.0.0.1`

![Kibana_7](images/Kibana_7.jpg)

* 此外还可直接点击以下按钮来过滤日志

![Kibana_14](images/Kibana_14.jpg)

### 自定义字段视图

可选定个别字段显示在日志栏中

![Kibana_13](images/Kibana_13.jpg)


## 创建可视化图表

Kibana可创建可视化图表(Visualize)来直观查看日志相关信息

如需要查看特定时间段访问最多的IP：

* 下图可以看到可以创建多种图表，此处选择柱状图

![Kibana_8](images/Kibana_8.jpg)

* 选择Index pattern

![Kibana_9](images/Kibana_9.jpg)

* Y轴选择数量(count),X轴选择访问IP对应的字段(remote_host),并按数量排序；**最后要记得保存图表**

![Kibana_10](images/Kibana_10.jpg)


按如上方法同样可以设定出“特定时间段被访问最多的页面”等要求的图表


## 仪表盘

仪表盘(Dashboard)是集中展示图表的地方，可以自定义添加经常需要查看和重要的图表

* 新建仪表盘，有之前就设定好的图表供选择

![Kibana_11](images/Kibana_11.jpg)

* 选择“访问IP排名”和“访问URL排名”，可以调整图表大小和位置，同样要记得**保存仪表盘**

![Kibana_12](images/Kibana_12.jpg)