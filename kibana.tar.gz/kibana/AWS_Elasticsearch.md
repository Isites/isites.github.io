# AWS Elasticsearch

----------
## ELK Stack简介
ELK是Elasticserach,Logstash与Kibana三种开源工具的简称，分别起到日志分析、日志收集和界面展示的功能

以下是ELK的基本架构：

* Logstash安装在需要收集日志的客户端，以agent的形式导入日志并加以过滤和分流导出到Elasticsearch或redis
* Elasticsearch(ES)中的数据按索引来划分的，可安装Head，Kopf等插件对ES进行可视化管理
* Kibana一般与ES安装在同一台主机上，其相关配置信息放在ES的".kibana"索引中

![ELK_STACK](images/ELK_STACK.jpg)

## AWS Elasticsearch 服务简介
由于自建ELK环境过程繁琐且管理复杂，故可以选择AWS Elasticsearch服务

以下是AWS ES服务架构图


![AWS_ES](images/AWS_ES.jpg)

* Logstash由Kinesis agent来代替
* Kinesis agent不直接把数据传输到ES，而是先输出到Kinesis Firehose，再由Firehose统一输出到ES
* 数据输出到ES的索引名称、日志类型、索引轮换周期都是在Firehose中配置

## AWS Elasticsearch的创建配置
### 创建Elasticsearch
ES service选择如下
![AWS_ES1](images/AWS_ES_1.jpg)
![AWS_ES2](images/AWS_ES_2.jpg)

版本选择5.1
![AWS_ES3](images/AWS_ES_3.jpg)

### 配置Elasticsearch
节点数建议选择2个及以上，容量
![AWS_ES4](images/AWS_ES_4.jpg)

可根据访问IP和AWS ID来设定访问策略

![AWS_ES5](images/AWS_ES_5.jpg)

## AWS Kinesis Firehose Delivery Stream的创建
### Step.1 重要配置
* Elasticsearch domain：选定好之前创建的ES domain
* Index：定义索引名称
* Index rotation:索引轮训（若为每天则新建一以日期结尾明明的索引，如nginx-access-2017-05-05）
* Type: 日志类型(每条日志都有的一个属性)
![Firehose_1](images/Firehose_1.jpg)

### Step.2 重要配置
* Buffer size: ES日志缓冲容量(MB)
* Buffer interval:缓冲写入ES的间隔时间(s)
* IAM Role:firehose_delivery_role
![Firehose_2](images/Firehose_2.jpg)

## AWS Kinesis Agent的安装和配置
* 安装:sudo yum install –y aws-kinesis-agent
* 编辑 /etc/sysconfig/aws-kinesis-agent 以指定您的区域和 AWS 访问密钥

	`AWS_ACCESS_KEY_ID=`

	`AWS_SECRET_ACCESS_KEY=`

	`AWS_DEFAULT_REGION=`

ID需要有Firehose PutRecordBatch权限

* 配置/etc/aws-kinesis/agent.json

		{
		   "cloudwatch.emitMetrics": true,
		   "firehose.endpoint": "firehose.us-east-1.amazonaws.com",
		   "flows": [
	         {
	           "filePattern": "/opt/data1/nginxlogs/access-js-test-www*-json.log",  #读取的日志文件
	           "deliveryStream": "ES-nginx-access",  #输出到firehose
	           "initialPosition": "START_OF_FILE"    #日志读取起始位置，默认为文件末尾
	         }
		    ]
		}

详情请见：
[Kinesis Agent配置](https://docs.aws.amazon.com/zh_cn/firehose/latest/dev/writing-with-agents.html#prereqs "Kinesis Agent配置")

* 开启agent service: sudo service aws-kinesis-agent start

## 查看AWS Elasticsearch

**查看ES健康状况**
![AWS_ES6](images/AWS_ES_6.jpg)

**可以看到下面已有数据输入ES生成索引**
![AWS_ES7](images/AWS_ES_7.jpg)

## Elasticsearch API
由于AWS ES service不可自定义安装插件，所以无法使用GUI来对ES进行管理

然而AWS ES管理控制台所提供的操作功能也很有限，故只能使用ES API来进行操作

如删除要删除索引nginx-access-log-2017-05-25-03:

	curl -XDELETE 'search-es-test-sm5nzhexuyjrkl6shdbfzndzw4.us-east-1.es.amazonaws.com/nginx-access-log-2017-05-25-03?pretty'

API使用详情请见：[Elasticsearch API](https://www.elastic.co/guide/en/elasticsearch/reference/current/index.html)

## AWS 服务费用

### Elasticsearch service

AWS ES根据节点和EBS存储使用时间来定价，详情请见：[Elasticsearch定价](https://aws.amazon.com/cn/elasticsearch-service/pricing/)

![AWS_ES_fee](images/AWS_ES_fee.jpg)

![AWS_ES_fee2](images/AWS_ES_fee2.jpg)

### Amazon Kinesis Firehose

Amazon Kinesis Firehose根据传输流量定价，详情请见：[Firehose定价](https://aws.amazon.com/cn/kinesis/firehose/pricing/)

![Firehose_fee](images/Firehose_fee.jpg)