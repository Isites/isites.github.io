# AWS 日志分析系统部署计划
_____________
## Kinesis Firehose DeliveryStream

![Firehose_3](images/Firehose_3.jpg)

根据以上Firehose DeliveryStream配置可知：ES Domain，Index，Type 3项设置决定了一个Stream

* Type根据收集的日志类型而定，比如nginx access log & error log,esmeralda log,syslog

* Index命名：[Type]-[Stack name]
  
  比如IK PC站的nginx access日志，则其index名称应为nginx-access-ik

  暂定JS所有站只按PC,Mobile来分(JS,MJS)，不分小站；其他站为IK,MIK,JE,MJE,AM,DF,PH

* Index rotation

  索引可定时进行循环切割；如按每天，则每天新建一个索引，索引名称为"nginx-access-ik-2017-06-16"这样的格式

  JS,MJS计划设定每周，其他站设定每月切割

* Delivery stream name 与 Index 名称相同

* **一个Index中只包含有一种日志类型，保证日志格式统一**

## Elasticsearch
* ES数据节点数(Instance count)暂且选择2个节点，Instance type选择default配置，若以后负载过高可增加节点或提高配置

* Dedicated Master为ES 集群的控制和监控服务器，当节点数较多时可以选择配置

* EBS volume容量暂定50GB，此处为单节点容量，若2个节点则一共使用100GB；EBS type选择SSD

![AWS_ES4](images/AWS_ES_4.jpg)

* ES访问策略选择根据来源IP来限制，可将本部出口公网IP和各代理服务器IP加入策略中

![AWS_ES8](images/AWS_ES_8.jpg)

## Kinesis Agent

Kinesis Agent 配置在 /etc/aws-kinesis/agent.json 下

配置模板如下：

	{
	"cloudwatch.emitMetrics": true,
	"firehose.endpoint": "firehose.us-east-1.amazonaws.com",

	"flows": [
    {
      "filePattern": "/opt/data1/nginxlogs/access-js-test-www-json.log",
      "deliveryStream": "ES-nginx-access"
    },
    {
      "filePattern": "/opt/data1/nginxlogs/access-js-test-www.log",
      "deliveryStream": "ES-nginx-converted",
      "dataProcessingOptions": [
                {
                    "optionName": "LOGTOJSON",
                    "logFormat": "COMBINEDAPACHELOG",
                    "matchPattern": "^([0-9.]+) - (\\S+) \\[.*?\\] \"(.*)\" ([0-9]{3}) ([0-9]+) \"(\\S+)\" \"(.*)\" (\\S+) \"(\\S+)\" (\\S+) (\\S+) (\\S+) \"(\\S+)\" (\\S+) \\[(.*)\\] (\\S+)$",
                    "customFieldNames": [ "remote_host" ,"authuser" ,"request" ,"response" ,"bytes" ,"referer" ,"user_agent" ,"uid" ,"cookie_JJSTID" ,"forwarded_for" ,"cookie_JJSID" ,"host" ,"cookie_abTest" ,"request_time" ,"timestamp" ,"node" ]
                }
            ]
    }
	]
	}


每个主机节点应有多种日志需要上传，每个“flow”为上传的一个stream路径；

一般情况下每一种日志类型设定一个“flow”对应相应的一个stream

  
## 部署

### Kinesis Agent

为了保证能够批量部署，kinesis agent需要配置为puppet部署方式

Agent 所需文件：

* 配置文件：/etc/aws-kinesis/agent.json

每个站点的配置文件都不相同，放置在prometheus下的stages\{stage_name}\puppet\files路径下

* 凭据access key文件: /etc/sysconfig/aws-kinesis-agent

`AWS_ACCESS_KEY_ID=`

`AWS_SECRET_ACCESS_KEY=`

`AWS_DEFAULT_REGION=`

由于是通用文件，放置在lestore_devops下的modules\lestore-vm\puppet\modules\lebbay\files\kinesis中

* puppet部署模块

		class lebbay::kinesis::agent {
			package{"aws-kinesis-agent":
				ensure => "installed"
			}
			
			file{"kinesis conf":                              #配置文件
			    path => "/etc/aws-kinesis/agent.json",
			    owner => "root",
			    group => "root",
			    mode => "0644",
			    source => "/home/ec2-user/puppet/files/kinesis-agent.json",
			    notify => Service["aws-kinesis-agent"],
			    require => Package["aws-kinesis-agent"];
			    "credential":                                 #凭据文件
			    path => "/etc/sysconfig/aws-kinesis-agent",
			    owner => "root",
			    group => "root",
			    mode => "0644",
			    source => "puppet:///modules/lebbay/kinesis/aws-kinesis-agent",
			    notify => Service["aws-kinesis-agent"],
			    require => Package["aws-kinesis-agent"];
			}
			
			
			service{"aws-kinesis-agent":
			    enable => true,
			    ensure => "running",
			    require => [Package["aws-kinesis-agent"],File["kinesis conf"]]
			}
		}

* 在prometheus的stage puppet文件中添加引用以下类：

		class { 'lebbay::kinesis::agent' :
		}

* app.mak: TARGET _puppet

添加以下命令语句：

		sudo mkdir -p $(PUPPET_ROOT)/files
		-sudo rm -fr $(PUPPET_ROOT)/files/*
		-sudo cp -fR $(STAGE_PATH)/puppet/files/* $(PUPPET_ROOT)/files/

在发布时将配置文件agent.json从代码分支中复制到puppet文件目录中以更新kinesis agent配置文件


### 日志格式更改
此处以nginx access log为例：

* access log 需要节点名称字段以及log time需要符合格式标准，在nginx.conf中更改log format如下：

		log_format apache_format '$remote_addr - $remote_user [$time_local] "$request" '
		                         '$status $body_bytes_sent "$http_referer" '
		                         '"$http_user_agent" $uid_l$uid_set$uid_got$uid_r "$cookie_JJSTID"'
		                         ' $http_x_forwarded_for $cookie_JJSID $host'
		                         ' "$cookie_abTest" $request_time [$time_iso8601] $node';

添加字段 [$time_iso8601] 和 $node

* nginx配置文件 {stack}.conf & {stack}.proxy.conf：
   
  添加语句 include app-snippets/{stake}.node，引用node变量，node即为节点名称

* app.mak: TARGET _nginx

		sudo bash -c 'sed -r "s#host_name=(.*)#set \$$node \1;#g" /var/job/host_name.conf > $(NGINX_CONF_DIR)/app-snippets/$(stage)$(underscore_multi).node'

在发布时将{stack}.node文件创建，其内容应为：
`set $node {hostname}`

