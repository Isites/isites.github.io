# Zabbix使用手册 #
_________________
## Zabbix简介 ##
### 结构 ###
zabbix是现今流行的开源监控系统，是典型的Server-Agent结构的系统，以下是其结构图

![zabbix_1](images/zabbix_1.jpg)

由上图可知Server端有数据库,zabbix\_server,Web console三部分组成，zabbix_server进程与web console分别与数据库通信

被监控端通过zabbix agent来与server互相通信，同时zabbix也支持分布式监控，agent与proxy进行通信，而server与proxy代理进行通信
### 监控方式 ###
* Agent

Agent监控方式就是使用zabbix agent来监控各个被监控对象，是zabbix系统所使用的主要监控方式

agent方式还分主动和被动方式：

主动方式是指被监控端定时地主动向服务器端发送监控数据，该种方式的优点是server端负载较低

被动方式是指server端定时轮询各主机的监控数据，使用此种方式如果监控对象较多则server端负担较重

server端侦听端口为10051，agent端侦听端口为10050

**我们此次主要使用的就是agent主动模式**

* SNMP

SNMP为简单网络管理协议，该协议是一种公有协议，绝大多数计算机和网络设备都支持该种通用协议；若要使用SNMP监控设备，在被监控端同样也要开启SNMP服务

SNMP将每一种监控资源如内存，硬盘使用率等都标识有一唯一标识符——OID，OID以树状结构来组织，如{1.3.6.1.2.1.1}，的父节点为{1.3.6.1.2.1}，其所有OID的集合为管理信息库(MIB)

* IPMI

IPMI即智能平台管理接口，用来监控服务器的硬件状况，如硬盘和CPU温度，内存、风扇、硬盘等部件的状况等；IPMI运行于服务器主板上，独立于OS、BIOS和CPU，只要服务器通电即自动运行；其不仅可以监控硬件状况，还可以进行远程开关机等操作

想要获取IPMI上硬件状况监控数据需要连接服务器上IPMI的端口，该端口与网络端口相同需要配置IP来通信

* JMX

JMX(Java Management Extensions,即Java管理扩展)是Java平台上为应用程序、设备、系统等植入管理功能的框架。JMX可以跨越一系列异构操作系统平台、系统体系结构和网络传输协议，灵活地开发无缝集成的系统、网络和服务管理应用。

在zabbix中有专门的代理程序zabbix-java-gateway来负责数据收集，其与JMX的java程序进行通信，zabbix-server再与zabbix-java-gateway通信，以下是其结构图

![zabbix_jmx](images/zabbix_jmx.jpg)

由于目前我们主要使用的是php平台，故该种监控方式也不适用

## 添加新建主机 ##

在zabbix中如何对新建主机进行监控添加配置，按如下步骤进行

### 客户端配置 ###

客户端无需手动安装，在主机部署时已由puppet自动安装，可关注一下agent端配置(/etc/zabbix/zabbix_agentd.conf)

**重要配置说明**

    Server=zabbix.opvalue.com          #被动模式下可以被哪些server轮询监控
	ServerActive=zabbix.opvalue.com    #开启主动模式，将数据发送的目标server
	Hostname=vb-prod-1-vbp1               #发送给server数据时附带的hostname，server以此来判别数据来源端而不是IP等其他信息
	HostMetadata=lbdevops-vb-prod-1-vbp1  #元数据，与server自动搜索和自动注册有关
	Timeout=15							  #被轮询监控数据时的最大查询执行时间
	Include=/etc/zabbix_agentd.conf.d/*.conf   
	Include=/etc/zabbix/zabbix_agentd.d/*.conf  #子配置文件
	UnsafeUserParameters=1                      #能否执行含有不安全参数的查询
	TLSConnect=psk                             #agent与server端通信的加密方式
	TLSAccept=psk                              #server端来轮询时能接受的通信加密方式
	TLSPSKFile=/etc/zabbix/zabbix_agentd.psk   #PSK密钥文件路径
	TLSPSKIdentity=PSK 001                     #PSK加密识别ID

要确保zabbix-agent服务已正常启动

### 添加安全组规则 ###

由于我们使用的是主动模式，因此agent需要访问server的10051端口，所以每新建一主机的监控就要在zabbix server的安全组里添加一条规则

如下图

![zabbix_sg](images/zabbix_sg.jpg)

还可通过AWS CLI批量添加

	aws ec2 authorize-security-group-ingress --profile jt --region  us-east-1 --group-name lestore-stage-zabbix-jjs-1-InstanceSecurityGroup-YKC5MPFLOPV8 --protocol tcp --port 10051 --cidr [IP]/32

### zabbix控制台端配置 ###

* 自动注册

由于配置的是主动模式，新主机在添加安全组规则后能自动注册到zabbix server中；关于自动注册的相关设置如下

![zabbix_auto_registration](images/zabbix_auto_registration.jpg)

由图中可知，若元数据中含有lbdevops字段则自动添加主机，并将主机添加进"linux servers"组、链接"Template OS Linux"监控模板

* 配置调整

默认的主机监控配置还不能满足我们的要求，还需要进行如下更改：

查看Discoverd hosts并勾选主机，点击"Mass update"批量更改

![zabbix_2](images/zabbix_2.jpg)

替换所属组，一般为linux servers,各站点group，若是前端服务器需要加入Frontend-prod组，若是JJS服务器还需加入JJS-PC或JJS-MB组

![zabbix_3](images/zabbix_3.jpg)

前端服务器需链接"Template Frontend service"模板

![zabbix_4](images/zabbix_4.jpg)

这步非常重要，设置加密方式，这步没有设置则agent server端无法互相通信

![zabbix_5](images/zabbix_5.jpg)

* 检查

在几分钟后检查主机是否已经连通，可查看图标"ZBX"是否变绿色，以此表明server端能与agent连通

![zabbix_6](images/zabbix_6.jpg)

另外还需要查看监控图形是否有输出，以此判断agent端能否连通server端，**一向能通不代表另一向也能通，双向都需要检查**

## 监控查询 ##

现有约200多台主机被纳入监控并收集有一段时间的监控数据，可通过如下几个方面查看主机状况

### 状态列表 ###

最基础直观的就是查看hosts状态列表

![zabbix_7](images/zabbix_7.jpg)

图中可以看到所有主机在线状态，一目了然

可以选择右上角group来过滤主机

### 监控图表 ###

对于大部分监控项都有数据图表来直观展示，下图可以看到是某台主机nginx连接数量的监控图表

可以选择右上角的组、主机和图表来查看；最下方表示每一颜色对应的是哪项数据，包含有最新值、最小值、平均值和最大值；还可选择查看时间区域

![zabbix_graph](images/zabbix_graph.jpg)

### 最新和历史数据 ###

对于每台主机的每个ITEM可以查看最新和历史监控数据

![zabbix_latest_data](images/zabbix_latest_data.jpg)

点击右边Graph，History可以看到收集到的监控历史数据，数值型的ITEM给出的是图形

![zabbix_latest_data_2](images/zabbix_latest_data_2.jpg)

![zabbix_latest_data_3](images/zabbix_latest_data_3.jpg)

### 告警提示 ###

在主页的dashboard可以看到主机报警；报警的启用需要配置触发器(trigger)

![zabbix_alert](images/zabbix_alert.jpg)

在Problems界面中可以看到更详细的信息

![zabbix_problems](images/zabbix_problems.jpg)

## zabbix监控配置 ##

### 监控项Item ###

每一项监控数据都是由监控项(Item)获取而来，如下图可以看到某一主机的Items

其中有Item名称，监控键值，轮询时间间隔，数据保留时间，监控方式(在此绝大多数为主动模式**zabbix agent(active)**)等

![zabbix_item_1](images/zabbix_item_1.jpg)

* **以下是ITEM的详细配置信息**

![zabbix_item_2](images/zabbix_item_2.jpg)

Parent items  **父监控项** 可以看出这是一个模板继承下来的监控

Key  **键名称** 决定了所要监控的数据，system.cpu.load字面上就可看出是CPU负载，[percpu,avg1]为参数，意为每个CPU平均1分钟的负载；key可以是zabbix内置的，也可以自定义

Type of information  **数据类型**  此处为浮点数，选错类型可能不能正确获取数据

update interval **轮询时间间隔**

History storage period **历史数据存放时间** 此处为一周

Trend storage period **趋势数据存放时间** 此处为365天，趋势数据就是历史数据的大时间段间隔的取样

Show value  **数据映射** 比如获取的数据为1，可以映射为Prod，由于触发器需要有数据大小判断，因此监控数据有时必须是数字，1可以代表为prod，2代表pre等

![zabbix_value_map](images/zabbix_value_map.jpg)

Applications **应用** 一种标签，便于分类

Populates host inventory field  **填入主机资产记录栏位**  将获取的数据填入资产信息表

* 自定义key

除了zabbix内置key,同时可以自定义key；自定义的数据监控项实际上就是在被监控端编写一脚本来获取所需要的数据，然后再定义key，并将定义的配置文件引用入agent配置文件，现举一nginx连接数的监控例子：

**数据获取脚本**

	#! /bin/bash

	case $1 in
	active )
		/usr/bin/curl "http://127.0.0.1:88/nginx_stub_status" 2>/dev/null | grep 'Active' | awk '{print $NF}'
		;;
	reading )
		/usr/bin/curl "http://127.0.0.1:88/nginx_stub_status" 2>/dev/null | grep 'Reading' | awk '{print $2}'
		;;
	writing )
		/usr/bin/curl "http://127.0.0.1:88/nginx_stub_status" 2>/dev/null | grep 'Writing' | awk '{print $4}'
		;;
	waiting )
		/usr/bin/curl "http://127.0.0.1:88/nginx_stub_status" 2>/dev/null | grep 'Waiting' | awk '{print $6}'
		;;
	accepts )
		/usr/bin/curl "http://127.0.0.1:88/nginx_stub_status" 2>/dev/null | awk NR==3 | awk '{print $1}'
		;;
	handled )
		/usr/bin/curl "http://127.0.0.1:88/nginx_stub_status" 2>/dev/null | awk NR==3 | awk '{print $2}'
		;;
	requests )
		/usr/bin/curl "http://127.0.0.1:88/nginx_stub_status" 2>/dev/null | awk NR==3 | awk '{print $3}'
		;;
		* )
		echo "usage: $0 [active|reading|writing|waiting|accepts|handled|requests]"
		;;
	esac

**key定义配置文件**

	UserParameter=custom.nginx.accepts,/var/job/zabbix_nginx_stub_status.sh accepts
	UserParameter=custom.nginx.handled,/var/job/zabbix_nginx_stub_status.sh handled
	UserParameter=custom.nginx.requests,/var/job/zabbix_nginx_stub_status.sh requests
	UserParameter=custom.nginx.connections.active,/var/job/zabbix_nginx_stub_status.sh active
	UserParameter=custom.nginx.connections.reading,/var/job/zabbix_nginx_stub_status.sh reading
	UserParameter=custom.nginx.connections.writing,/var/job/zabbix_nginx_stub_status.sh writing
	UserParameter=custom.nginx.connections.waiting,/var/job/zabbix_nginx_stub_status.sh waiting

其中可以看到key其实就是一一对应一条命令来获取其输出数据；key还可以使用参数如下

	UserParameter=custom.mysql.status[*],/var/job/zabbix_mysql.sh $1 $2

Item配置

![zabbix_custom_key](images/zabbix_custom_key.jpg)

### 自动发现Discovery rule ###

有时你是不确定每台主机的具体情况的，监控项目不能完全确定，比如文件系统分区，zabbix就有自动发现功能，如下图

![zabbix_discover_rule](images/zabbix_discover_rule.jpg)

扫描到的对象会自动添加ITEM,Trigger,Graph

![zabbix_discover_item](images/zabbix_discover_item.jpg)

![zabbix_discover_trigger](images/zabbix_discover_trigger.jpg)

![zabbix_discover_graph](images/zabbix_discover_graph.jpg)

### 触发器Trigger ###

Trigger触发器即为报警触发器，trigger配置示例如下

![zabbix_trigger_1](images/zabbix_trigger_1.jpg)

Trigger最重要的配置就是Expression，其就是报警阈值或条件的配置，上图表达式的含义就是当根分区剩余空间小于10%时触发警告

除了典型的最新数值大小判断还有如最近n个数据或一段时间的数据中最大值、平均值大小判断，最近2个数据差异或者大小判断等多种判断方式

如以下表达式：

	{Zabbix server:custom.website.pagespeed[www.veryvoga.com,desktop].max(#3)}<60
	最近3次数据最大值小于60时触发报警

	{Zabbix server:vfs.file.cksum[/etc/passwd].diff(0)}>0
	/etc/passwd md5值发生变化，即该文件被更改时触发报警

	{Zabbix server:agent.ping.nodata(5m)}=1
	agent ping最近5分钟无响应数据时触发报警

同时trigger配置中还有其他参数：

"OK event generation"意为状态恢复条件："Expression"不触发公式条件即为恢复；"Recovery Expression"另外定义恢复条件；"None"无恢复事件

"PROBLEM event generation mode"问题事件生成模式:"Single"只触发一次，"Multiple"每次都触发

"Allow manual close": 允许手动关闭报警

"URL": 指定报警访问地址，对应宏{TRIGGER.URL}

### 依赖Dependency ###

有时各报警触发具有相关性，如服务器宕机则各个触发器大部分都会被触发，此时实际上只有一个报警是被需要的，那就是服务器无法连接，对于此种情况可使用trigger中的Dependency依赖功能，示例如下

![zabbix_trigger_dependency](images/zabbix_trigger_dependency.jpg)

配置页

![zabbix_trigger_dependency2](images/zabbix_trigger_dependency2.jpg)

以上依赖的意思为：若主机在预生产环境中，则报警不触发，"{HOST.NAME} is not in production environment"也是一个trigger,**当被依赖trigger触发时，本触发器不触发报警**
![zabbix_pre_env_trigger](images/zabbix_pre_env_trigger.jpg)

**注意：模板中的trigger不能依赖某个host的trigger，依赖只能同样来自于模板**

### 图表Graph ###

zabbix中可以将收集到的历史数据制成图表来展示，可使用标准坐标系图、层积图和饼状图，示例图见之前"监控图表"一节中的"nginx performance",其配置如下

![zabbix_graph_conf](images/zabbix_graph_conf.jpg)

可以将多个Item数据添加进同一个图表中

* Function中的选项avg意思为当此Item每次单次收集到多个数据则取它们的平均值，但平常使用的Item单次只会收集到一个数据，因此Function配置意义不大

* Draw Style选择的是数据图线型，此处为梯形线

* color为线的颜色

层积图为多个Item数据图线相互叠加，而不是重叠，与适用于饼状图的监控对象相同，都是几个Item对象的值相加为固定值，如CPU使用率等

![zabbix_CPU_utilization](images/zabbix_CPU_utilization.jpg)

### 模板Template ###

我们平时监控的主机大多数监控项目都是相同的，如果每台主机都要配置一遍的话未免工作量太大，因此zabbix中有模板功能，将监控配置标准化

下图可以看到模板列表与主机列表相似，只是没有agent状态，多了链接主机，其配置方式几乎与单台主机的监控配置一模一样，在此不做赘述

![zabbix_templates](images/zabbix_templates.jpg)

* 链接

主机链接模板的方式如下图，一般都是在主机新添加入zabbix中时已批量链接

![zabbix_template_link](images/zabbix_template_link.jpg)

链接模板以后模板中的Item,trigger,graph等配置就会自动应用到主机中，以下可以看到Item来自于哪个模板

![zabbix_template_items](images/zabbix_template_items.jpg)

* 导入导出

为方便备份或共享，模板还能够导入导出，导入方式见下图

![zabbix_template_export](images/zabbix_template_export.jpg)

导出的模板文件为XML格式

![zabbix_template_file](images/zabbix_template_file.jpg)

若网上有共享的监控模板下载下来，可以通过如下方式导入

![zabbix_template_import](images/zabbix_template_import.jpg)

导入的时候可以选择只导入模板中部分内容

![zabbix_template_import_2](images/zabbix_template_import_2.jpg)

### 邮件报警 ###

能够收到邮件报警的流程大致如下：

Item成功收集到数据——>Trigger触发警告——>触发符合条件的Trigger类型Action

Item与Trigger的配置方法之前已经说过，接下来就是Action和邮件的配置

* 邮件配置

首先需要配置Media type报警媒介类型，我们这里配置的是邮件类型Mail，还有Script脚本类型、SMS短信类型(zabbix server需要安装短信Modem)、Jabber类型(发送IM信息)

配置如下,zabbix server将邮件发送至本地的SMTP服务端口，端口为25，发件人为zabbix@zabbix-jjs-1-zbxjs1.ec2.internal，因为是本地地址无需配置SSL/TLS加密

![zabbix_media_type](images/zabbix_media_type.jpg)

接下来需要给User配置邮箱，**Type注意要选择之前配置的报警媒介**

![zabbix_user_media](images/zabbix_user_media.jpg)

* 动作配置

发送邮件报警的动作需要在configuration中的Actions配置，现已配置有如下，注意选择右上角的事件来源，不通事件来源对应不同种类的动作，之前提到的自动注册(Auto registration)也是Action的一种

![zabbix_actions](images/zabbix_actions.jpg)

在此以其中已配置好的action为例

第一个配置页为条件，可以配置的条件为报警等级、触发器名称、是否维护状态、主机名称等，并且可以设置多个条件直接的与或关系，**最后的"Enable"一定要勾选**，此处并未启用该action

![zabbix_trigger_action_1](images/zabbix_trigger_action_1.jpg)

第二个配置页为通知操作，设定发送邮件的标题、内容和收件人等

下图可知邮件内容标题是使用宏填写主机名称、报警名称和等级信息的，收件人可以为个人或者用户组；

注意"Send only to"，每个用户配有多个报警媒介，注意选择所需要的媒介；

Steps表示报警触发连续第几次时执行操作，1-3意为第一次到第三次，1-0表示第一次开始到最后一次；

Step duration表示间隔几次触发

![zabbix_trigger_action_2](images/zabbix_trigger_action_2.jpg)

后面两个配置页：报警恢复操作和报警确认操作的配置方式与以上相同

### 动作Action ###

Action除了“自动注册”和“触发器”类型以外还有“内部事件源(Internal)”和“自动发现(Discovery)”两种类型

* 内部事件源

内部事件源action可以报告状态异常的Item和Trigger等工作

![zabbix_action_internal](images/zabbix_action_internal.jpg)

* 自动发现

自动发现与自动注册的功能类似，都是自动添加主机，区别和agent的被动和主动模式类似：自动发现是zabbix server扫描指定IP地址段内的主机并自动添加，而自动注册是agent端主动发出申请注册进zabbix系统中

配置如下供参考，与自动注册的配置方式类似（我们现并未用到此种action）

![zabbix_action_discovery_1](images/zabbix_action_discovery_1.jpg)

![zabbix_action_discovery_2](images/zabbix_action_discovery_2.jpg)
